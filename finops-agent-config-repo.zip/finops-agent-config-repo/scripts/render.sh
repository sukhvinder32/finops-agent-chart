#!/usr/bin/env bash
# Renders one cluster folder the same way Config Sync's hydration does,
# so you can review the output before merging.
#
# Usage:
#   ./scripts/render.sh envs/rtl/pre/caas-01/clusters/ew1-msv-pre-caas01-svp02-gke01
set -euo pipefail

target="${1:?usage: render.sh <cluster folder>}"

# Config Sync renders with Helm enabled and without the root-only load
# restriction; the cluster kustomization reads values from ../../../base.
kustomize build --enable-helm --load-restrictor LoadRestrictionsNone "${target}"

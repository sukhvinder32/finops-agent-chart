#!/usr/bin/env bash
# Vendors Helm chart dependencies into helm/<chart>/charts/ so that
# Kustomize (and Config Sync's hydration) can render the charts offline.
#
# finops-agent depends on oci://registry-1.docker.io/bitnamicharts/common.
# Without the vendored .tgz, `kustomize build --enable-helm` fails with
# "found in Chart.yaml, but missing in charts/ directory".
#
# Run from the repo root, then commit the generated .tgz files:
#   ./scripts/vendor-chart-deps.sh
#   git add helm/*/charts/*.tgz
set -euo pipefail

cd "$(dirname "$0")/.."

for chart in helm/*/; do
  if grep -q '^dependencies:' "${chart}Chart.yaml"; then
    echo ">> vendoring dependencies for ${chart}"
    # 'build' honours Chart.lock, so you get the exact pinned versions.
    helm dependency build "${chart}"
  fi
done

echo ">> done. Commit helm/*/charts/*.tgz"

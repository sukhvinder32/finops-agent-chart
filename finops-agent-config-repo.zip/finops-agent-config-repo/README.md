# finops-agent-config-repo

GitOps repo for deploying the IBM FinOps Agent (Cloudability mode) with
Config Sync RootSync, following the "Helm chart → environment defaults →
cluster-specific overrides" pattern.

Upstream chart: https://github.com/kubecost/finops-agent-chart
(chart `finops-agent` 1.0.30, app v1.0.30)

## Layout

```text
repo-root/
├── helm/
│   └── finops-agent/                 # upstream chart, unmodified
│       ├── Chart.yaml
│       ├── Chart.lock
│       ├── values.yaml
│       ├── templates/
│       └── charts/                   # vendored deps (run scripts/vendor-chart-deps.sh)
├── envs/
│   └── rtl/
│       ├── int/                      # same shape as pre/, clusters ew1-msv-int-*
│       ├── prd/                      # same shape as pre/, clusters ew1-msv-prd-*
│       └── pre/
│           ├── base/
│           │   └── finops-agent/     # environment layer for rtl/pre
│           │       ├── kustomization.yaml
│           │       ├── namespace.yaml
│           │       ├── secretproviderclass.yaml
│           │       └── values/
│           │           └── finops-agent-common.yaml
│           ├── caas-01/
│           │   └── clusters/
│           │       └── ew1-msv-pre-caas01-svp02-gke01/      # RootSync dir
│           │           ├── patches/
│           │           │   └── cloudability_secrets/
│           │           │       └── cloudability_secret_patch.yaml
│           │           ├── values/
│           │           │   └── finops-agent.yaml
│           │           └── kustomization.yaml
│           └── tool-01/
│               └── clusters/
│                   └── ew1-msv-pre-tool01-example-gke01/    # RootSync dir
│                       ├── patches/
│                       │   └── cloudability_secrets/
│                       │       └── cloudability_secret_patch.yaml
│                       ├── values/
│                       │   └── finops-agent.yaml
│                       └── kustomization.yaml
└── scripts/
    ├── vendor-chart-deps.sh
    ├── render.sh
    └── rootsync-examples.yaml
```

## How the layers fit

| Layer | Where | What lives there |
|---|---|---|
| Chart | `helm/finops-agent/` | Upstream chart. Do not edit; upgrade by replacing the folder. |
| Environment | `envs/rtl/<int\|pre\|prd>/base/finops-agent/` | Namespace, SecretProviderClass skeleton, common values (Cloudability on, CSI mount, service account name). |
| Cluster | `envs/rtl/<env>/<caas>/clusters/<cluster>/` | `clusterId`, Workload Identity annotation, patch pointing the SecretProviderClass at this cluster's Secret Manager secrets. |

Values precedence: chart `values.yaml` → `finops-agent-common.yaml` → cluster
`values/finops-agent.yaml` (last wins).

## How credentials flow

1. Three secrets live in GCP Secret Manager: Cloudability access key,
   secret key and environment ID.
2. The SecretProviderClass maps each one to a file name the agent expects
   (`CLOUDABILITY_KEY_ACCESS`, `CLOUDABILITY_KEY_SECRET`, `CLOUDABILITY_ENV_ID`).
3. The CSI volume mounts those files at `/opt/cloudability` in the agent pod.
4. The chart's own Secret is turned off (`secret.create: false`,
   `existingSecret: ""`), so nothing lands in etcd and there is no
   Secret-must-exist-before-pod ordering problem.

## Before first sync

- [ ] Run `./scripts/vendor-chart-deps.sh` and commit `helm/finops-agent/charts/common-2.41.0.tgz`.
- [ ] Replace every `REPLACE_ME*` (projects, secret names, GSA emails, repo URL).
- [ ] Confirm `agent.cloudability.uploadRegion` for your tenant.
- [ ] Confirm the CSI provider: `gcp` (open-source driver) or `gke` (GKE managed add-on).
- [ ] Grant the agent's identity `roles/secretmanager.secretAccessor` on the three secrets.
- [ ] Render each cluster locally: `./scripts/render.sh envs/rtl/pre/caas-01/clusters/ew1-msv-pre-caas01-svp02-gke01`.
- [ ] Create one RootSync per cluster, six in total (see `scripts/rootsync-examples.yaml`).

## Adding a cluster

Copy an existing cluster folder, rename it to the cluster name, then change
`clusterId`, the Workload Identity annotation and the patch's project/secret names.
Point a new RootSync at the new folder.

## Deviations from the platform layout guide

- `helm/finops-agent/charts/` **is required**. The chart depends on Bitnami
  `common`; Helm cannot render it without the vendored archive.
- The SecretProviderClass is not part of the chart, so it is added as a
  resource in the environment layer and patched per cluster (rather than
  patching a chart-owned resource as in the Dynatrace example).
- `scripts/` is added at the top level for repeatable vendoring and rendering.
  It is not under any RootSync `dir`, so Config Sync never applies it.
